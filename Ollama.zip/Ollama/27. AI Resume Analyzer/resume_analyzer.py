
import ollama

def generate_response(prompt):
    response = ollama.generate(model="llama3.2", prompt=prompt)
    return response["response"]

print("===== AI RESUME ANALYZER =====")

with open("resume.txt", "r", encoding="utf-8") as file:
    resume = file.read()

prompt = f"""
Analyze the following resume.

Resume Content:
{resume}

Provide:
1. Important skills.
2. Educational qualifications.
3. Brief candidate profile summary.
4. Suggestions for resume improvement.
"""

result = generate_response(prompt)

print("\n===== RESUME ANALYSIS =====")
print(result)
