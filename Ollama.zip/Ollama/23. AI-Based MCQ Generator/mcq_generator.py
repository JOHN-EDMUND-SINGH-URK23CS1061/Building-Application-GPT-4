
import ollama

def generate_response(prompt):
    response = ollama.generate(model="llama3.2", prompt=prompt)
    return response["response"]

print("===== AI-BASED MCQ GENERATOR =====")

subject = input("\nEnter subject: ")
topic = input("Enter topic: ")

prompt = f"""
Generate exactly five multiple-choice questions.

Subject: {subject}
Topic: {topic}

For each question:
1. Provide four options (A, B, C, D).
2. Identify the correct answer.
3. Display the questions in numbered format.
"""

result = generate_response(prompt)

print("\n===== GENERATED MCQs =====")
print(result)
