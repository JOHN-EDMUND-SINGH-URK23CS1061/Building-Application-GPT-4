
import ollama

def generate_response(prompt):
    response = ollama.generate(model="llama3.2", prompt=prompt)
    return response["response"]

print("===== AI DAILY TASK PLANNER =====")

tasks = input("\nEnter your tasks (separated by commas): ")
time = input("Enter available time: ")

prompt = f"""
Create a suitable daily schedule.

Tasks: {tasks}
Available Time: {time}

Requirements:
1. Organize all the tasks.
2. Assign suitable time slots.
3. Arrange tasks in a logical order.
4. Include short breaks if possible.
5. Display the final schedule clearly.
"""

result = generate_response(prompt)

print("\n===== YOUR DAILY SCHEDULE =====")
print(result)
