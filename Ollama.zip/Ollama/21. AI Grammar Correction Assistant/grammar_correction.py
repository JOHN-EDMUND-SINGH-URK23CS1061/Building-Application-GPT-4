
import ollama

def generate_response(prompt):
    response = ollama.generate(model="llama3.2", prompt=prompt)
    return response["response"]

def save_file(filename, content):
    with open(filename, "w", encoding="utf-8") as file:
        file.write(content)
    print("\nFile saved successfully!")

print("===== GRAMMAR CORRECTION ASSISTANT =====")

text = input("\nEnter a sentence or paragraph: ")

prompt = f"""
Correct all grammatical and spelling errors
in the following text.

Text: {text}

Preserve the original meaning.
Display only the corrected text.
"""

result = generate_response(prompt)

print("\n===== CORRECTED TEXT =====")
print(result)

save_file("corrected_text.txt", result)
