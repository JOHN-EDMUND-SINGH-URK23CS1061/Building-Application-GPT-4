
import ollama

def generate_response(prompt):
    response = ollama.generate(model="llama3.2", prompt=prompt)
    return response["response"]

def save_file(filename, content):
    with open(filename, "w", encoding="utf-8") as file:
        file.write(content)
    print("\nFile saved successfully!")

print("===== AI PRODUCT DESCRIPTION GENERATOR =====")

product = input("\nEnter product name: ")
features = input("Enter product features: ")
customers = input("Enter target customers: ")

prompt = f"""
Generate an attractive product description.

Product Name: {product}
Features: {features}
Target Customers: {customers}

Write an engaging and professional description.
Highlight the important features and benefits.
"""

result = generate_response(prompt)

print("\n===== PRODUCT DESCRIPTION =====")
print(result)

save_file("product_description.txt", result)
