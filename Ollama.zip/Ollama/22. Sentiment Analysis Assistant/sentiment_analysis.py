
import ollama

def generate_response(prompt):
    response = ollama.generate(model="llama3.2", prompt=prompt)
    return response["response"]

print("===== SENTIMENT ANALYSIS ASSISTANT =====")

text = input("\nEnter customer review or feedback: ")

prompt = f"""
Analyze the sentiment of the following text.

Text: {text}

Classify it as Positive, Negative or Neutral.
Provide a brief explanation for the classification.
"""

result = generate_response(prompt)

print("\n===== SENTIMENT ANALYSIS RESULT =====")
print(result)
