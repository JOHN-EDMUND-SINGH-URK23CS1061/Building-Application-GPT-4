
import ollama

# Function to generate response using Ollama
def generate_response(prompt):
    response = ollama.generate(
        model="llama3.2",
        prompt=prompt
    )
    return response["response"]


# Main program
print("===== AI-POWERED MEDICAL INFORMATION ASSISTANT =====")

# Read health information
with open("health_info.txt", "r", encoding="utf-8") as file:
    health_information = file.read()

print("\nAsk a general health information question.")
print("Type exit to stop.")

# Accept questions continuously
while True:
    question = input("\nEnter your question: ")

    if question.lower() == "exit":
        print("\nThank you for using the medical assistant!")
        break

    # Create prompt
    prompt = f"""
You are a general health information assistant.

Use the information below to answer the question.
Do not diagnose diseases or prescribe medicines.
If the information is not available, say so.

Health Information:
{health_information}

Question: {question}

Provide a simple and clear answer.
"""

    # Generate response
    result = generate_response(prompt)

    # Display result
    print("\n===== MEDICAL INFORMATION =====")
    print(result)

    # Display disclaimer
    print("\nDisclaimer: This is general educational information "
          "and is not a substitute for professional medical advice.")
