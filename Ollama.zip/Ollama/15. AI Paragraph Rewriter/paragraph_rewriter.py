
import ollama

def generate_response(prompt):
    response = ollama.generate(model="llama3.2", prompt=prompt)
    return response["response"]

def save_file(filename, content):
    with open(filename, "w", encoding="utf-8") as file:
        file.write(content)
    print("\nFile saved successfully!")

print("===== AI PARAGRAPH REWRITER =====")

paragraph = input("\nEnter a paragraph: ")
style = input("Enter style (Formal/Simple/Professional): ")

prompt = f"""
Rewrite the following paragraph in {style} style.

Paragraph:
{paragraph}

Preserve the original meaning.
Display only the rewritten paragraph.
"""

result = generate_response(prompt)

print("\n===== REWRITTEN PARAGRAPH =====")
print(result)

save_file("rewritten_text.txt", result)
