
import ollama

def generate_response(prompt):
    response = ollama.generate(
        model="llama3.2",
        prompt=prompt
    )
    return response["response"]

def save_file(filename, content):
    with open(filename, "w", encoding="utf-8") as file:
        file.write(content)
    print("\nFile saved successfully!")

print("===== MEETING MINUTES GENERATOR =====")

notes = input("\nEnter meeting notes: ")

prompt = f"""
Convert the following meeting notes into structured
meeting minutes.

Meeting Notes:
{notes}

Include:
1. Meeting Summary.
2. Important Decisions.
3. Action Items.
4. Use clear headings and bullet points.
5. Do not invent information that is not in the notes.
"""

result = generate_response(prompt)

print("\n===== GENERATED MEETING MINUTES =====")
print(result)

save_file("meeting_minutes.txt", result)
