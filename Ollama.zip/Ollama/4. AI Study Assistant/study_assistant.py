
import ollama

def generate_response(prompt):
    response = ollama.generate(
        model="llama3.2",
        prompt=prompt
    )
    return response["response"]

print("===== AI STUDY ASSISTANT =====")

topic = input("\nEnter an academic topic: ")

prompt = f"""
Explain the academic topic: {topic}

Provide:
1. A simple explanation using easy language.
2. A suitable real-world example.
3. Keep the explanation clear and understandable
   for a student.
"""

result = generate_response(prompt)

print("\n===== TOPIC EXPLANATION =====")
print(result)
