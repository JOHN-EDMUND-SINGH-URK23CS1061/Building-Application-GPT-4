
import ollama

def generate_response(prompt):
    response = ollama.generate(model="llama3.2", prompt=prompt)
    return response["response"]

print("===== AI KEYWORD EXTRACTOR =====")

paragraph = input("\nEnter a paragraph: ")

prompt = f"""
Analyze the following paragraph.

Paragraph:
{paragraph}

Extract:
1. Important keywords.
2. Key phrases.
3. Main concepts.

Display the results in a clear numbered format.
"""

result = generate_response(prompt)

print("\n===== EXTRACTED KEYWORDS =====")
print(result)
