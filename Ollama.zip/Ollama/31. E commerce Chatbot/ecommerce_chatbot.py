
import ollama

# Function to generate response using Ollama
def generate_response(prompt):
    response = ollama.generate(
        model="llama3.2",
        prompt=prompt
    )
    return response["response"]


# Main program
print("===== E-COMMERCE CHATBOT =====")

# Product dataset
products = [
    {"Product": "Laptop", "Price": 45000, "Description": "8GB RAM, 512GB SSD"},
    {"Product": "Mobile", "Price": 15000, "Description": "6GB RAM, 128GB storage"},
    {"Product": "Headphones", "Price": 2000, "Description": "Wireless headphones"},
    {"Product": "Keyboard", "Price": 800, "Description": "USB keyboard"},
    {"Product": "Mouse", "Price": 500, "Description": "Wireless mouse"}
]

# Display available products
print("\nAvailable Products:")

for product in products:
    print(
        product["Product"],
        "- Rs.", product["Price"],
        "-", product["Description"]
    )

# Accept customer questions
while True:
    question = input("\nAsk a question (type exit to stop): ")

    if question.lower() == "exit":
        print("\nThank you for visiting our online store!")
        break

    # Create prompt
    prompt = f"""
You are an e-commerce chatbot.

Use only the product information below.
Do not invent products, prices or features.
If the requested information is not available, say so.

Product Information:
{products}

Customer Question: {question}

Answer clearly and helpfully.
"""

    # Generate response
    result = generate_response(prompt)

    # Display result
    print("\n===== CHATBOT RESPONSE =====")
    print(result)
