
import ollama

def generate_response(prompt):
    response = ollama.generate(
        model="llama3.2",
        prompt=prompt
    )
    return response["response"]

print("===== SENTIMENT ANALYSIS APPLICATION =====")

review = input("\nEnter customer review: ")

prompt = f"""
You are a sentiment analysis assistant.
Analyze the following customer review.

Classify the sentiment into one of these categories:
Positive, Negative, or Neutral.

Also provide a brief explanation for your classification.

Customer Review: {review}

Display the sentiment and explanation clearly.
"""

result = generate_response(prompt)

print("\n===== SENTIMENT ANALYSIS RESULT =====")
print(result)
