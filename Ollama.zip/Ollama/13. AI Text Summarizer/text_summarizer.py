
import ollama

def generate_response(prompt):
    response = ollama.generate(model="llama3.2", prompt=prompt)
    return response["response"]

def save_file(filename, content):
    with open(filename, "w", encoding="utf-8") as file:
        file.write(content)
    print("\nFile saved successfully!")

print("===== AI TEXT SUMMARIZER =====")

text = input("\nEnter a long paragraph: ")

prompt = f"""
Summarize the following text.

Text:
{text}

Provide:
1. A concise summary.
2. The main ideas in bullet points.
"""

result = generate_response(prompt)

print("\n===== TEXT SUMMARY =====")
print(result)

save_file("summary.txt", result)
