
import ollama

def generate_response(prompt):
    response = ollama.generate(model="llama3.2", prompt=prompt)
    return response["response"]

print("===== CUSTOMER FEEDBACK ANALYZER =====")

feedback = input("\nEnter customer feedback: ")

prompt = f"""
Analyze the following customer feedback.

Feedback: {feedback}

Provide:
1. Main complaint or appreciation.
2. Sentiment classification: Positive, Negative or Neutral.
3. An appropriate action based on the feedback.
"""

result = generate_response(prompt)

print("\n===== FEEDBACK ANALYSIS =====")
print(result)
