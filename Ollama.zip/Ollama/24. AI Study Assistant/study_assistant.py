
import ollama

def generate_response(prompt):
    response = ollama.generate(model="llama3.2", prompt=prompt)
    return response["response"]

print("===== AI STUDY ASSISTANT =====")

topic = input("\nEnter an academic topic: ")

prompt = f"""
Explain the following academic topic: {topic}

Provide:
1. A simple explanation.
2. A relevant example.
3. Three important points to remember.

Use easy language suitable for students.
"""

result = generate_response(prompt)

print("\n===== STUDY ASSISTANT RESULT =====")
print(result)
