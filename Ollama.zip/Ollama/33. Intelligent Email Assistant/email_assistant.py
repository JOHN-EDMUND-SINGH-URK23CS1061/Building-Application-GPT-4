
import ollama

# Function to generate response using Ollama
def generate_response(prompt):
    response = ollama.generate(
        model="llama3.2",
        prompt=prompt
    )
    return response["response"]


# Function to save email reply
def save_file(filename, content):
    with open(filename, "w", encoding="utf-8") as file:
        file.write(content)
    print("\nEmail saved successfully!")


# Main program
print("===== INTELLIGENT EMAIL ASSISTANT =====")

# Accept input from user
email = input("\nEnter the received email: ")
tone = input("Enter tone (Formal/Friendly/Professional): ")

# Create prompt
prompt = f"""
You are an intelligent email assistant.

Read the received email and write an appropriate reply.

Received Email:
{email}

Preferred Tone: {tone}

Include:
1. A suitable subject line.
2. Greeting.
3. Email body.
4. Closing.

Do not invent facts that are not given in the email.
"""

# Generate email reply
result = generate_response(prompt)

# Display result
print("\n===== GENERATED EMAIL REPLY =====")
print(result)

# Save result in file
save_file("email_reply.txt", result)
