
import ollama

def generate_response(prompt):
    response = ollama.generate(model="llama3.2", prompt=prompt)
    return response["response"]

print("===== AI ASSIGNMENT TOPIC GENERATOR =====")

subject = input("\nEnter subject: ")
interest = input("Enter area of interest: ")

prompt = f"""
Generate exactly five relevant assignment topics.

Subject: {subject}
Area of Interest: {interest}

For each topic:
1. Provide a suitable title.
2. Give a brief description.
"""

result = generate_response(prompt)

print("\n===== ASSIGNMENT TOPICS =====")
print(result)
