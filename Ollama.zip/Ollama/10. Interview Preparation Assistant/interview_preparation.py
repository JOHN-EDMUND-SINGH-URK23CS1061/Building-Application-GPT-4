
import ollama

def generate_response(prompt):
    response = ollama.generate(model="llama3.2", prompt=prompt)
    return response["response"]

print("===== INTERVIEW PREPARATION ASSISTANT =====")

subject = input("\nEnter technical subject: ")
difficulty = input("Enter difficulty (Beginner/Intermediate/Advanced): ")

prompt = f"""
Generate exactly five technical interview questions
on the subject: {subject}

Difficulty Level: {difficulty}

Provide:
1. Five interview questions.
2. A clear answer for each question.
3. Use numbered formatting.
"""

result = generate_response(prompt)

print("\n===== INTERVIEW QUESTIONS AND ANSWERS =====")
print(result)
