
import ollama

def generate_response(prompt):
    response = ollama.generate(
        model="llama3.2",
        prompt=prompt
    )
    return response["response"]

def save_file(filename, content):
    with open(filename, "w", encoding="utf-8") as file:
        file.write(content)
    print("\nFile saved successfully!")

print("===== AI FLASHCARD GENERATOR =====")

topic = input("\nEnter a topic: ")

prompt = f"""
Generate exactly five study flashcards
on the topic: {topic}

Each flashcard must contain:
1. A question.
2. Its corresponding answer.

Display them in a numbered format.
"""

result = generate_response(prompt)

print("\n===== GENERATED FLASHCARDS =====")
print(result)

save_file("flashcards.txt", result)
