
import ollama

def generate_response(prompt):
    response = ollama.generate(
        model="llama3.2",
        prompt=prompt
    )
    return response["response"]

print("===== AI-BASED MCQ GENERATOR =====")

topic = input("\nEnter a topic: ")

prompt = f"""
Generate exactly five multiple-choice questions
on the topic: {topic}

For each question:
1. Give four options (A, B, C, D).
2. Mention the correct answer.
3. Keep the questions clear and educational.
"""

result = generate_response(prompt)

print("\n===== GENERATED MCQs =====")
print(result)
