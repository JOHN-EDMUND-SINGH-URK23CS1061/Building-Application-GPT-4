
import ollama

# Function to generate response using Ollama
def generate_response(prompt):
    response = ollama.generate(
        model="llama3.2",
        prompt=prompt
    )
    return response["response"]


# Main program
print("===== PERSONALIZED COURSE RECOMMENDATION SYSTEM =====")

# Course dataset
courses = [
    {"Course": "Python Programming", "Category": "Programming", "Level": "Beginner"},
    {"Course": "Machine Learning", "Category": "Artificial Intelligence", "Level": "Intermediate"},
    {"Course": "Data Science", "Category": "Analytics", "Level": "Beginner"},
    {"Course": "Cyber Security", "Category": "Security", "Level": "Intermediate"},
    {"Course": "Computer Networks", "Category": "Networking", "Level": "Beginner"},
    {"Course": "Deep Learning", "Category": "Artificial Intelligence", "Level": "Advanced"}
]

# Accept input from user
name = input("\nEnter student name: ")
interest = input("Enter your interest: ")
skill = input("Enter skill level (Beginner/Intermediate/Advanced): ")

# Create prompt
prompt = f"""
You are a personalized course recommendation assistant.

Student Name: {name}
Student Interest: {interest}
Student Skill Level: {skill}

Available Courses:
{courses}

Recommend exactly three suitable courses only from the available list.
Give a short explanation for each recommendation.
Do not invent courses.
Consider the student's interest and skill level.
"""

# Generate recommendations
result = generate_response(prompt)

# Display result
print("\n===== RECOMMENDED COURSES =====")
print(result)
