
import ollama

def generate_response(prompt):
    response = ollama.generate(model="llama3.2", prompt=prompt)
    return response["response"]

def save_file(filename, content):
    with open(filename, "w", encoding="utf-8") as file:
        file.write(content)
    print("\nFile saved successfully!")

print("===== TEXT TRANSLATION ASSISTANT =====")

text = input("\nEnter a paragraph: ")
language = input("Enter target language: ")

prompt = f"""
Translate the following paragraph into {language}.
Preserve its original meaning.

Paragraph:
{text}

Display only the translated text.
"""

result = generate_response(prompt)

print("\n===== TRANSLATED TEXT =====")
print(result)

save_file("translated_text.txt", result)
