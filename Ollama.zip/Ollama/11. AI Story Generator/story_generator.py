
import ollama

def generate_response(prompt):
    response = ollama.generate(model="llama3.2", prompt=prompt)
    return response["response"]

def save_file(filename, content):
    with open(filename, "w", encoding="utf-8") as file:
        file.write(content)
    print("\nFile saved successfully!")

print("===== AI STORY GENERATOR =====")

topic = input("\nEnter story topic: ")
genre = input("Enter genre (Fantasy/Adventure/Mystery/Science Fiction): ")
audience = input("Enter audience (Children/Teenagers/Adults): ")

prompt = f"""
Write a short story based on the following details.

Topic: {topic}
Genre: {genre}
Target Audience: {audience}

Generate an interesting and creative story.
"""

result = generate_response(prompt)

print("\n===== GENERATED STORY =====")
print(result)

save_file("story.txt", result)
