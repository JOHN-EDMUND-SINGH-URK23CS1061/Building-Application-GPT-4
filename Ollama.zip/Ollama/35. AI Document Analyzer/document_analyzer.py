
import ollama

# Function to generate response using Ollama
def generate_response(prompt):
    response = ollama.generate(
        model="llama3.2",
        prompt=prompt
    )
    return response["response"]


# Main program
print("===== AI DOCUMENT ANALYZER =====")

# Accept file name from user
filename = input("\nEnter text file name (example: ai.txt): ")

try:
    # Read document
    with open(filename, "r", encoding="utf-8") as file:
        document = file.read()

    # Display document
    print("\n===== DOCUMENT CONTENT =====")
    print(document)

    # Create summary prompt
    summary_prompt = f"""
Summarize the following document in simple language.
Use only the information in the document.

Document:
{document}
"""

    # Generate summary
    summary = generate_response(summary_prompt)

    print("\n===== DOCUMENT SUMMARY =====")
    print(summary)

    # Accept question
    question = input("\nEnter your question about the document: ")

    # Create question prompt
    question_prompt = f"""
Answer the question using only the document below.

If the answer is not available, say:
Information not available in the document.

Document:
{document}

Question: {question}
"""

    # Generate answer
    answer = generate_response(question_prompt)

    # Display answer
    print("\n===== ANSWER =====")
    print(answer)

    # Save results
    with open("analysis_result.txt", "w", encoding="utf-8") as file:
        file.write("SUMMARY:\n" + summary)
        file.write("\n\nQUESTION:\n" + question)
        file.write("\n\nANSWER:\n" + answer)

    print("\nResults saved as analysis_result.txt")

except FileNotFoundError:
    print("\nFile not found. Check the filename and try again.")
