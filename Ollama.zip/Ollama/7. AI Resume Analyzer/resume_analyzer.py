
import ollama

def generate_response(prompt):
    response = ollama.generate(model="llama3.2", prompt=prompt)
    return response["response"]

print("===== AI RESUME ANALYZER =====")

with open("resume.txt", "r", encoding="utf-8") as file:
    resume = file.read()

prompt = f"""
Analyze the following resume.

Resume:
{resume}

Provide:
1. Candidate's skills.
2. Qualifications.
3. Brief resume summary.
4. Areas for improvement.
"""

result = generate_response(prompt)

print("\n===== RESUME ANALYSIS =====")
print(result)
