
import ollama

def generate_response(prompt):
    response = ollama.generate(model="llama3.2", prompt=prompt)
    return response["response"]

def save_file(filename, content):
    with open(filename, "w", encoding="utf-8") as file:
        file.write(content)
    print("\nFile saved successfully!")

print("===== AI EMAIL ASSISTANT =====")

email = input("\nEnter original email content: ")
tone = input("Enter desired tone (Formal/Friendly/Professional): ")

prompt = f"""
Generate an appropriate email reply.

Original Email:
{email}

Desired Tone: {tone}

Include:
1. Suitable subject.
2. Greeting.
3. Main message.
4. Appropriate closing.

Use a clear and professional email format.
"""

result = generate_response(prompt)

print("\n===== GENERATED EMAIL REPLY =====")
print(result)

save_file("email_reply.txt", result)
