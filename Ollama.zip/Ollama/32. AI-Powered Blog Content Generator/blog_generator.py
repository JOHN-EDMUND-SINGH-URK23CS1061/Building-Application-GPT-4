
import ollama

# Function to generate response using Ollama
def generate_response(prompt):
    response = ollama.generate(
        model="llama3.2",
        prompt=prompt
    )
    return response["response"]


# Function to save blog content
def save_file(filename, content):
    with open(filename, "w", encoding="utf-8") as file:
        file.write(content)
    print("\nBlog saved successfully!")


# Main program
print("===== AI BLOG CONTENT GENERATOR =====")

# Accept input from user
topic = input("\nEnter blog topic: ")
style = input("Enter writing style (Formal/Casual/Informative): ")

# Create prompt
prompt = f"""
You are an AI blog content generator.

Write a blog on the topic: {topic}
Use this writing style: {style}

Include:
1. An attractive title.
2. Introduction.
3. Main content with headings.
4. Conclusion.

Generate clear and informative content.
"""

# Generate blog
result = generate_response(prompt)

# Display result
print("\n===== GENERATED BLOG =====")
print(result)

# Save result in file
save_file("blog.txt", result)
