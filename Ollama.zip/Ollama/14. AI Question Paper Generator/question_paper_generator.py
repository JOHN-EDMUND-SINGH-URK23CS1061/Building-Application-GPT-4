
import ollama

def generate_response(prompt):
    response = ollama.generate(model="llama3.2", prompt=prompt)
    return response["response"]

print("===== AI QUESTION PAPER GENERATOR =====")

subject = input("\nEnter subject: ")
topic = input("Enter topic: ")
number = input("Enter number of questions: ")

prompt = f"""
Generate {number} questions and answers.

Subject: {subject}
Topic: {topic}

Provide:
1. Numbered questions.
2. A correct answer for each question.
3. Clear and educational content.
"""

result = generate_response(prompt)

print("\n===== GENERATED QUESTIONS AND ANSWERS =====")
print(result)
