
import ollama

def generate_response(prompt):
    response = ollama.generate(model="llama3.2", prompt=prompt)
    return response["response"]

def save_file(filename, content):
    with open(filename, "w", encoding="utf-8") as file:
        file.write(content)
    print("\nFile saved successfully!")

print("===== MEETING MINUTES GENERATOR =====")

notes = input("\nEnter meeting notes: ")

prompt = f"""
Convert the following notes into meeting minutes.

Meeting Notes:
{notes}

Include:
1. Concise meeting summary.
2. Important decisions.
3. Action items.
4. Responsibilities assigned to team members.

Do not invent decisions or responsibilities.
"""

result = generate_response(prompt)

print("\n===== MEETING MINUTES =====")
print(result)

save_file("meeting_minutes.txt", result)
