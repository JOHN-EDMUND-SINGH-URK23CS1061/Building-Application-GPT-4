
import ollama

def generate_response(prompt):
    response = ollama.generate(
        model="llama3.2",
        prompt=prompt
    )
    return response["response"]

print("===== AI INTERVIEW PREPARATION ASSISTANT =====")

subject = input("\nEnter technical subject: ")

difficulty = input(
    "Enter difficulty level (Beginner/Intermediate/Advanced): "
)

prompt = f"""
You are a technical interview preparation assistant.

Generate exactly five interview questions
on the following subject: {subject}

Difficulty Level: {difficulty}

For each question:
1. Display the interview question.
2. Provide a clear and correct answer.
3. Use simple language.
4. Number all five questions.
"""

result = generate_response(prompt)

print("\n===== INTERVIEW QUESTIONS AND ANSWERS =====")
print(result)
