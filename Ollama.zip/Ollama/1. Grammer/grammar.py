
import ollama

# Function to generate response using Ollama
def generate_response(prompt):
    response = ollama.generate(
        model="llama3.2",
        prompt=prompt
    )
    return response["response"]


# Function to save corrected text
def save_file(filename, content):
    with open(filename, "w", encoding="utf-8") as file:
        file.write(content)
    print("\nFile saved successfully!")


# Main program
print("===== GRAMMAR CORRECTION ASSISTANT =====")

# Accept input from user
text = input("\nEnter a sentence or paragraph: ")

# Create prompt
prompt = f"""
You are a grammar correction assistant.

Identify and correct grammatical and spelling errors.
Preserve the original meaning of the text.

Text: {text}

Display only the corrected text.
"""

# Generate corrected text
result = generate_response(prompt)

# Display result
print("\n===== CORRECTED TEXT =====")
print(result)

# Save result in file
save_file("corrected_text.txt", result)
