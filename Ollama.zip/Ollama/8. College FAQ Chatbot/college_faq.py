
import ollama

def generate_response(prompt):
    response = ollama.generate(model="llama3.2", prompt=prompt)
    return response["response"]

print("===== COLLEGE FAQ CHATBOT =====")

faqs = """
Q: What courses are offered?
A: Computer Science, Mechanical, Civil and ECE.

Q: What are the library timings?
A: The library is open from 9 AM to 5 PM.

Q: When are examinations conducted?
A: Examinations are conducted at the end of each semester.

Q: How can I apply for admission?
A: Students can apply through the college admission office.
"""

question = input("\nAsk your college-related question: ")

prompt = f"""
You are a college FAQ chatbot.
Answer the user's question using ONLY the FAQ information below.

FAQ Information:
{faqs}

User Question: {question}

If the answer is not available in the FAQ,
clearly say: "Sorry, this information is not available."
Do not invent information.
"""

result = generate_response(prompt)

print("\n===== CHATBOT RESPONSE =====")
print(result)
